module.exports = {
  setupFiles: ['<rootDir>/src/test/setup.js']
}